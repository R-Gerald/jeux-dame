package config;

public class Config_client {
    public static final String SERVER_ADDRESS = "localhost"; // Adresse du serveur
    public static final int SERVER_PORT = 1234; // Port du serveur
}