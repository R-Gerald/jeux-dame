package config;

public class Config_message {
    public static final String CONNECTION_MESSAGE = "Vous êtes connecté au serveur.";
}