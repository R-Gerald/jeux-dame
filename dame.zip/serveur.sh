#!/bin/bash

# Compiler tous les fichiers Java dans le répertoire courant et ses sous-répertoires
java -cp bin serveur.Serveur
