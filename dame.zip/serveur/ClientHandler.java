package serveur;

import java.io.*;
import java.net.*;

public class ClientHandler extends Thread {
    private Socket clientSocket;
    private BufferedReader in;
    private PrintWriter out;
    private Serveur serveur; // Reference to the server class

    public ClientHandler(Socket socket, Serveur serveur) throws IOException {
        this.clientSocket = socket;
        this.serveur = serveur; // Assign the server reference
        this.in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        this.out = new PrintWriter(clientSocket.getOutputStream(), true);
    }

    @Override
public void run() {
    try {
        String inputLine;
        while ((inputLine = in.readLine()) != null) {
            serveur.broadcast(inputLine); // Diffuser le mouvement à tous les clients
        }
    } catch (IOException e) {
        System.err.println("Erreur lors de la gestion du client : " + e.getMessage());
    } finally {
        try {
            clientSocket.close();
        } catch (IOException e) {
            System.err.println("Erreur lors de la fermeture du socket client : " + e.getMessage());
        }
    }
}

    public void sendMessage(String message) {
        out.println(message); // Envoyer un message au client
    }
}
