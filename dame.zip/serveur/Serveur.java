package serveur;

import java.util.Set;
import java.util.HashSet;
import java.io.*;
import java.net.*;
import config.Config_server;

public class Serveur {
    private static Set<ClientHandler> clientHandlers = new HashSet<>(); // Ensemble des clients connectés

    public static void main(String[] args) {
        Serveur serveur = new Serveur(); // Créer une instance de Serveur
        serveur.startServer(); // Appeler la méthode pour démarrer le serveur
    }

    public void startServer() {
        System.out.println("Serveur démarré sur le port " + Config_server.PORT);
        try (ServerSocket serverSocket = new ServerSocket(Config_server.PORT)) {
            while (true) {
                Socket clientSocket = serverSocket.accept(); // Accepter une nouvelle connexion
                System.out.println("Nouvelle connexion acceptée : " + clientSocket);
                ClientHandler clientHandler = new ClientHandler(clientSocket, this); // Passer l'instance de Serveur
                clientHandlers.add(clientHandler);
                new Thread(clientHandler).start(); // Démarrer un nouveau thread pour gérer le client
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void broadcast(String message) {
        System.out.println("Diffusion du message : " + message); // Afficher le message avant de le diffuser
        for (ClientHandler client : clientHandlers) {
            client.out.println(message); // Envoyer le message à tous les clients
        }
    }

    private class ClientHandler implements Runnable {
        private Socket clientSocket;
        private PrintWriter out;
        private BufferedReader in;
        private Serveur serveur; // Référence à l'instance de Serveur

        public ClientHandler(Socket socket, Serveur serveur) {
            this.clientSocket = socket;
            this.serveur = serveur; // Initialiser la référence
            try {
                out = new PrintWriter(clientSocket.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        @Override
public void run() {
    String inputLine;
    try {
        while ((inputLine = in.readLine()) != null) {
            System.out.println("Mouvement reçu : " + inputLine); // Afficher le mouvement reçu
            // Diffuser le mouvement à tous les clients
            serveur.broadcast(inputLine); // Utiliser l'instance de Serveur pour appeler broadcast
        }
    } catch (IOException e) {
        e.printStackTrace();
    } finally {
        try {
            clientSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
    }
}