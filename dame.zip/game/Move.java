package game;

import java.awt.*;

public class Move {
    private Point from;
    private Point to;

    public Move(Point from, Point to) {
        this.from = from;
        this.to = to;
    }

    public Point getFrom() {
        return from;
    }

    public Point getTo() {
        return to;
    }

    @Override
    public String toString() {
        return from.x + "," + from.y + "->" + to.x + "," + to.y; // Format de chaîne pour le mouvement
    }
}