package game;

public class Piece {
    private String color; // 'W' pour blanc, 'B' pour noir
    private boolean isKing; // Indique si la pièce est une dame

    public Piece(String color) {
        this.color = color;
        this.isKing = false; // Initialement, la pièce n'est pas une dame
    }

    public String getColor() {
        return color;
    }

    public boolean isKing() {
        return isKing;
    }

    public void promoteToKing() {
        this.isKing = true; // Promouvoir la pièce en dame
    }
}