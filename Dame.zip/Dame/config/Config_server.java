package config;

public class Config_server {
    public static final int PORT = 1234;
}