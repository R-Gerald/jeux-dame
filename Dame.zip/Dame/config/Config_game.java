package config;

public class Config_game {
    public static final int BOARD_SIZE = 8; // Taille du plateau
    public static final String WHITE_PIECE = "W"; // Représentation d'un pion blanc
    public static final String BLACK_PIECE = "B"; // Représentation d'un pion noir
    public static final String WHITE_KING = "DW"; // Représentation d'une dame blanche
    public static final String BLACK_KING = "DB"; // Représentation d'une dame noire
    public static final int INITIAL_WHITE_PIECES = 12; // Nombre initial de pions blancs
    public static final int INITIAL_BLACK_PIECES = 12; // Nombre initial de pions noirs
}