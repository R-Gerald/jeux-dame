package game;

import javax.swing.*;
import client.ClientSocket;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;

public class DameGame extends JFrame {
    private static final int BOARD_SIZE = 8;
    private JButton[][] buttons = new JButton[BOARD_SIZE][BOARD_SIZE];
    private String currentPlayer; // 'W' pour le joueur blanc, 'B' pour le joueur noir
    private Point selectedPiece = null; // Initialisé à null
    private ClientSocket clientSocket; // Instance de ClientSocket
    private JTextArea moveHistory = new JTextArea();
    private int cellSize = 60; // Taille de chaque cellule du plateau
    private int totalCountW = 12; // Compteur initial de pions blancs
    private int totalCountB = 12; // Compteur initial de pions noirs


    public DameGame(String address, int port, String playerColor) {
        this.currentPlayer = playerColor; // Assigner la couleur du joueur

        try {
            clientSocket = new ClientSocket(address, port, this); // Passer l'instance de DameGame
        } catch (IOException e) {
            e.printStackTrace(); // Gérer l'exception
            System.exit(1); // Quitter si la connexion échoue
        }

        setTitle("Jeu de Dames");
        setSize(800, 600);
        setLayout(new BorderLayout());

        JPanel boardPanel = new JPanel(new GridLayout(BOARD_SIZE, BOARD_SIZE));
        initializeBoard(boardPanel);
        add(boardPanel, BorderLayout.CENTER);

        moveHistory.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(moveHistory);
        scrollPane.setPreferredSize(new Dimension(200, 600));
        add(scrollPane, BorderLayout.EAST);

        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private void initializeBoard(JPanel boardPanel) {
       
        for (int row = 0; row < BOARD_SIZE; row++) {
            for (int col = 0; col < BOARD_SIZE; col++) {
                buttons[row][col] = new JButton() {
                    @Override
                    protected void paintComponent(Graphics g) {
                        super.paintComponent(g);
                        String piece = getText();
                        if (piece.equals("B")) {
                            g.setColor(Color.BLACK);
                            g.fillOval(10, 10, getWidth() - 20, getHeight() - 20);
                        } else if (piece.equals("W")) {
                            g.setColor(Color.WHITE);
                            g.fillOval(10, 10, getWidth() - 20, getHeight() - 20);
                        } else if (piece.equals("DW")) {
                            g.setColor(Color.WHITE);
                            g.fillOval(10, 10, getWidth() - 20, getHeight() - 20);
                            g.setColor(Color.RED);
                            g.drawString("D", getWidth() / 2 - 5, getHeight() / 2 + 5); // D pour dame blanche
                        } else if (piece.equals("DB")) {
                            g.setColor(Color.BLACK);
                            g.fillOval(10, 10, getWidth() - 20, getHeight() - 20);
                            g.setColor(Color.RED);
                            g.drawString("D", getWidth() / 2 - 5, getHeight() / 2 + 5); // D pour dame noire
                        }
                    }
                };
                buttons[row][col].setPreferredSize(new Dimension(cellSize, cellSize)); // Utilisation de cellSize
                buttons[row][col].setBackground((row + col) % 2 == 0 ? Color.WHITE : Color.GRAY);
                buttons[row][col].setEnabled(true); // Activer les boutons
                buttons[row][col].addMouseListener(new BoardMouseListener(row, col));
                boardPanel.add(buttons[row][col]);
            }
        }
        drawInitialPieces();
    }

    private void drawInitialPieces() {
        // Placement initial des pièces
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < BOARD_SIZE; col++) {
                if ((row + col) % 2 == 1) {
                    buttons[row][col].setText("B"); // Pions noirs
                }
            }
        }
        for (int row = 5; row < BOARD_SIZE; row++) {
            for (int col = 0; col < BOARD_SIZE; col++) {
                if ((row + col) % 2 == 1) {
                    buttons[row][col].setText("W"); // Pions blancs
                }
            }
        }
    }

    private class BoardMouseListener extends MouseAdapter {
        private int row, col;

        public BoardMouseListener(int row, int col) {
            this.row = row;
            this.col = col;
        }

        @Override
        public void mouseClicked(MouseEvent e) {
           
            handlePieceSelection(row, col);
        }
    }

    private void handlePieceSelection(int row, int col) {
        System.out.println("handlePieceSelection appelé pour : " + row + ", " + col);
        String piece = buttons[row][col].getText();
        System.err.println("piece:"+piece);
        if (piece.equals(currentPlayer) || piece.equals("D" + currentPlayer)) {
            selectedPiece = new Point(row, col); // Sélectionner la pièce
        } else if (selectedPiece != null) {
            if (isValidMove(selectedPiece, new Point(row, col))) {
                movePiece(selectedPiece, new Point(row, col));
                // Vérifier si le joueur peut capturer à nouveau après le mouvement
                if (canCaptureAgain(new Point(row, col))) {
                    selectedPiece = new Point(row, col); // Garder la pièce sélectionnée pour une autre capture
                } else {
                    selectedPiece = null; // Réinitialiser la sélection si aucune autre capture n'est possible
                    switchPlayer();
                }
                
    
                checkGameOver();
               
            }
        }
    }
    private void switchPlayer() {
        currentPlayer = currentPlayer.equals("W") ? "B" : "W"; // Alterner entre 'W' et 'B'
    }

    private boolean isValidMove(Point from, Point to) {
        // Logique pour vérifier si le mouvement est valide
        int rowDiff = to.x - from.x;
        int colDiff = to.y - from.y;
        String piece = buttons[from.x][from.y].getText();

        // Vérifier les mouvements simples
        if (piece.equals("W") && rowDiff == -1 && Math.abs(colDiff) == 1) return true; // Mouvement blanc
        if (piece.equals("B") && rowDiff == 1 && Math.abs(colDiff) == 1) return true; // Mouvement noir

        // Vérifier les mouvements de dame
        if (piece.equals("DW") && Math.abs(rowDiff) == 1 && Math.abs(colDiff) == 1) return true;
        if (piece.equals("DB") && Math.abs(rowDiff) == 1 && Math.abs(colDiff) == 1) return true;

        // Vérifier les captures
        if (Math.abs(rowDiff) == 2 && Math.abs(colDiff) == 2) {
            int middleRow = (from.x + to.x) / 2;
            int middleCol = (from.y + to.y) / 2;
            String middlePiece = buttons[middleRow][middleCol].getText();
            if (!middlePiece.isEmpty() && !middlePiece.equals(currentPlayer) && !middlePiece.equals("D" + currentPlayer)) {
                return true; // Capture valide
            }
        }

        return false; // Mouvement invalide
    }

    public void processReceivedMove(String move) {
        String[] parts = move.split(" ");
        if (parts.length == 3) {
            Point from = new Point(8 - Integer.parseInt(parts[1].substring(1)), parts[1].charAt(0) - 'a');
            Point to = new Point(8 - Integer.parseInt(parts[2].substring(1)), parts[2].charAt(0) - 'a');
            System.out.println("from =="+from.getX()+" "+from.getY());
            System.out.println("to =="+to.getX()+" "+to.getY());
            updateBoard(from, to); // Mettre à jour le plateau
            updateMoveHistory(move); // Mettre à jour l'historique
         
        }
    }

    private void checkGameOver() {
        if (totalCountW == 0) {
            JOptionPane.showMessageDialog(this, "Les Noirs ont gagné !");
            System.exit(0);
        } else if (totalCountB == 0) {
            JOptionPane.showMessageDialog(this, "Les Blancs ont gagné !");
            System.exit(0);
        }
    }

    private void updateBoard(Point start, Point end) {
        // Convertir les coordonnées en entiers
        int startX = (int) start.getX();
        int startY = (int) start.getY();
        int endX = (int) end.getX();
        int endY = (int) end.getY();
    
        System.out.println("Coordonnées converties: start (" + startX + ", " + startY + "), end (" + endX + ", " + endY + ")");
    
        // Vérifier les indices
        if (startX < 0 || startX >= buttons.length || startY < 0 || startY >= buttons[0].length ||
            endX < 0 || endX >= buttons.length || endY < 0 || endY >= buttons[0].length) {
            System.out.println("Indices hors limites !");
            return;
        }
    
        // Vérifier si la case de départ contient une pièce
        String piece = buttons[startX][startY].getText();
        System.out.println("Texte à la case de départ [" + startX + "][" + startY + "] : " + piece);
        if(piece.isEmpty())
        {
            System.out.println("vide ilay depart");
        }

        if (piece == null || piece.isEmpty()) {
            System.out.println("Erreur : la case de départ est vide !");
            return;
        }
    
        // Déplacer la pièce
        buttons[endX][endY].setText(piece);
        buttons[startX][startY].setText(""); // Effacer l'ancienne position
        
       
        System.out.println("Texte à la case de destination [" + endX + "][" + endY + "] : " + buttons[endX][endY].getText());
    
        // Vérifier la capture
        if (Math.abs(startX - endX) == 2) {
            int midRow = (startX + endX) / 2;
            int midCol = (startY + endY) / 2;
            buttons[midRow][midCol].setText(""); // Enlever la pièce capturée
            System.out.println("Capture détectée !");
        }
    
        // Promotion à dame
        if (endX == 0 && piece.equals("W")) {
            buttons[endX][endY].setText("DW"); // Dame pour blanc
        } else if (endX == 7 && piece.equals("B")) {
            buttons[endX][endY].setText("DB"); // Dame pour noir
        }
    }
    
    
    private void updateMoveHistory(String move) {
        moveHistory.append(move + "\n");
    }

    private boolean canCaptureAgain(Point currentPosition) {
        // Logique pour vérifier si le joueur a des captures possibles à partir de la position actuelle
        int row = currentPosition.x;
        int col = currentPosition.y;

        // Vérifiez les directions possibles pour une capture
        for (int dRow = -2; dRow <= 2; dRow += 2) {
            for (int dCol = -2; dCol <= 2; dCol += 2) {
                if (isInBounds(row + dRow, col + dCol) && isInBounds(row + dRow / 2, col + dCol / 2)) {
                    String targetPiece = buttons[row + dRow][col + dCol].getText();
                    String middlePiece = buttons[row + dRow / 2][col + dCol / 2].getText();

                    // Vérifiez si la case cible est vide et s'il y a une pièce adverse à capturer
                    if (targetPiece.isEmpty() && (middlePiece.equals("B") || middlePiece.equals("W"))) {
                        return true; // Capture possible
                    }
                }
            }
        }
        return false; // Aucune capture possible
    }

    private boolean isInBounds(int row, int col) {
        return row >= 0 && row < BOARD_SIZE && col >= 0 && col < BOARD_SIZE;
    }

    private void movePiece(Point from, Point to) {
        System.out.println("movePiece appelé pour : " + from + " -> " + to);
        String piece = buttons[from.x][from.y].getText();
        buttons[to.x][to.y].setText(piece);
        buttons[from.x][from.y].setText(""); // Vider l'ancienne position
        moveHistory.append("Moved " + piece + " from (" + from.x + ", " + from.y + ") to (" + to.x + ", " + to.y + ")\n");

        // Format du mouvement à envoyer au serveur
        String move = piece + " " + (char) ('a' + from.y) + (8 - from.x) + " " + (char) ('a' + to.y) + (8 - to.x);
        clientSocket.sendMessage(move); // Envoyer le mouvement au serveur

        // Gérer les captures
        if (Math.abs(to.x - from.x) == 2) {
            int middleRow = (from.x + to.x) / 2;
            int middleCol = (from.y + to.y) / 2;
            buttons[middleRow][middleCol].setText(""); // Enlever la pièce capturée
            if (piece.equals("W")) totalCountB--; // Décrementer le compteur des noirs
            if (piece.equals("B")) totalCountW--; // Décrementer le compteur des blancs
        }

        // Promotion en dame
        if (to.x == 0 && piece.equals("W")) {
            buttons[to.x][to.y].setText("DW"); // Promotion en dame blanche
        } else if (to.x == BOARD_SIZE - 1 && piece.equals("B")) {
            buttons[to.x][to.y].setText("DB"); // Promotion en dame noire
        }
    }

    public static void main(String[] args) {
        if (args.length < 3) {
            System.out.println("Usage: java DameGame <address> <port> <playerColor>");
            System.exit(1);
        }
        String address = args[0];
        int port = Integer.parseInt(args[1]);
        String playerColor = args[2]; // 'W' ou 'B'
        new DameGame(address, port, playerColor);
    }
} 