package client;

import java.io.IOException;
import game.DameGame;

public class Main {
    public static void main(String[] args) {
        try {
            DameGame dameGame = new DameGame("localhost", 1234, "W"); // "W" pour le joueur blanc
            ClientSocket client = new ClientSocket("localhost", 1234, dameGame);
            client.listenForMoves(); // Assurez-vous que cette ligne est présente
            client.sendMove("a3 a4"); // Exemple de mouvement
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}