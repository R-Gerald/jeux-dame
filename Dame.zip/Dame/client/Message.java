package client;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;
import config.Config_message;

public class Message {
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;

    public Message(String serveurAdresse, int port) {
        try {
            socket = new Socket(serveurAdresse, port);
            System.out.println(Config_message.CONNECTION_MESSAGE);

            // Thread to receive messages from the server
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            Thread receptionThread = new Thread(() -> {
                try {
                    String message;
                    while ((message = in.readLine()) != null) {
                        System.out.println("Message reçu du serveur : " + message);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
            receptionThread.start();

            // Send messages to the server
            out = new PrintWriter(socket.getOutputStream(), true);
            try (Scanner scanner = new Scanner(System.in)) { // Use try-with-resources for Scanner
                String message;
                while (true) {
                    System.out.print("Akinya > ");
                    message = scanner.nextLine();

                    if ("exit".equalsIgnoreCase(message)) {
                        break;
                    }

                    out.println(message); // Send the message to the server
                }
            } // The scanner will be closed automatically here
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (socket != null && !socket.isClosed()) {
                    socket.close();
                    System.out.println("Connexion au serveur fermée.");
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        if (args.length < 2) {
            System.out.println("Usage: java client.Message <adresse_serveur> <port>");
            return;
        }
        String serveurAdresse = args[0];
        int port = Integer.parseInt(args[1]);
        new Message(serveurAdresse, port);
    }
}