package client;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

import game.DameGame;

public class ClientSocket {
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private DameGame dameGame;

    public ClientSocket(String address, int port, DameGame dameGame) throws IOException {
        this.dameGame = dameGame;
        socket = new Socket(address, port);
        out = new PrintWriter(socket.getOutputStream(), true);
        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        listenForMoves();
    }

    public void sendMove(String move) {
        out.println(move);
    }

    public String receiveResponse() throws IOException {
        return in.readLine();
    }

    public void close() throws IOException {
        in.close();
        out.close();
        socket.close();
    }

    public void listenForMoves() {
        new Thread(() -> {
            try {
                while (true) {
                    String response = receiveResponse();
                    if (response != null) {
                        dameGame.processReceivedMove(response);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();
    }

    // Méthode pour gérer les messages provenant de ClientHandler
    public void handleMessage(String message) {
        System.out.println("Message reçu via ClientHandler: " + message);
        dameGame.processReceivedMove(message);
    }

    

     public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Demander à l'utilisateur l'adresse IP et le port
        System.out.print("Entrez l'adresse IP du serveur : ");
        String address = scanner.nextLine();
        
        System.out.print("Entrez le port du serveur : ");
        int port = scanner.nextInt();
        scanner.nextLine();  

        try {
          
            DameGame dameGame = new DameGame("localhost", 1234, "W");
         
            ClientSocket client = new ClientSocket(address, port, dameGame);
            
            client.sendMove("a3 a4");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            scanner.close(); 
        }
    }

    public void sendMessage(String message) {
        try {
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            out.println(message); // Envoyer le message au serveur
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
}
